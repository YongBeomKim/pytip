# https://wikidiff.com/utility/tool
# `utility` is a program designed to perform a single or a small range of tasks
# `tool` is A mechanical device intended to make a task easier.

# utility : 독립적 프로그램
# tools   : 부가적

from .checker import check_folder_file, Message, check_ip
from .deco import web_retries, elapsed_time
from .file import multiprocess_items, pickle_data, download_file

